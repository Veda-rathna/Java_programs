package AJP_Practicals;

//Stream Generator For Prime Numbers.

import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Unit3Ex2 {

    // Method to generate an infinite stream of prime numbers
    public static Stream<Integer> primes() {
        return Stream.iterate(2, Unit3Ex2::nextPrime);
    }

    // Helper method to find the next prime number
    private static int nextPrime(int after) {
        int candidate = after + 1;
        while (!isPrime(candidate)) {
            candidate++;
        }
        return candidate;
    }

    // Method to check if a number is prime
    private static boolean isPrime(int number) {
        if (number < 2) return false;
        if (number == 2 || number == 3) return true;
        if (number % 2 == 0 || number % 3 == 0) return false;

        int sqrt = (int) Math.sqrt(number);
        for (int i = 5; i <= sqrt; i += 6) {
            if (number % i == 0 || number % (i + 2) == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter the number of prime numbers to generate: ");
            int count = scanner.nextInt();

            if (count <= 0) {
                System.out.println("Number of primes should be greater than zero.");
                return;
            }

            // Generate the stream of prime numbers and collect them into a list
            String result = primes()
                    .limit(count)
                    .map(Object::toString)
                    .collect(Collectors.joining(", "));

            System.out.println("Generated " + count + " prime numbers: " + result);
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid integer.");
        } finally {
            scanner.close();
        }
    }
}

